# -*- coding: utf-8 -*-
import os
import sys
import time

base_str = 'bash ./mytest.sh '
final_dict = {'two_phase_commit': ['node=6'],
              'blockchain': ['node=2 block=2 transaction=2 time=2'],
              'chord': ['node=4'],
              'consensus': ['quorum=2 node=3 value=2'],
              'database_chain_replication': ['transaction=3 operation=3 key=1 node=2'],
              'decentralized_lock': ['node=4'],
              'distributed_lock': ['node=2 epoch=4'],
              'leader': ['node=3 id=3'],
              'lock_server': ['client=2 server=1'],
              'multi_lock_server': ['node=4 lock=2'],
              'paxos': ['node=6 value=3 quorum=2 round=3'],
              'Ricart-Agrawala': ['node=2'],
              'shard': ['key=2 node=2 value=2'],
              'switch': ['node=3 packet=1']}
total_dict = {'two_phase_commit': ['node=2', 'node=3', 'node=4', 'node=5', 'node=6'],
              'blockchain': ['node=2 block=2 transaction=2 time=2'],
              'chord': ['node=2', 'node=3', 'node=4'],
              'consensus': ['quorum=2 node=2 value=1', 'quorum=2 node=2  value=2', 'quorum=3 node=2 value=1',
                            'quorum=3 node=2 value=2', 'quorum=2 node=3  value=1', 'quorum=2 node=3  value=2'],
              'database_chain_replication': ['transaction=1 operation=1 key=1 node=2',
                                             'transaction=2 operation=1 key=1 node=2',
                                             'transaction=1 operation=2 key=1 node=2',
                                             'transaction=1 operation=1 key=2 node=2',
                                             'transaction=2 operation=2 key=1 node=2',
                                             'transaction=2 operation=1 key=2 node=2',
                                             'transaction=1 operation=2 key=2 node=2',
                                             'transaction=3 operation=1 key=1 node=2',
                                             'transaction=1 operation=3 key=1 node=2',
                                             'transaction=1 operation=1 key=3 node=2',
                                             'transaction=2 operation=2 key=2 node=2',
                                             'transaction=3 operation=2 key=1 node=2',
                                             'transaction=3 operation=1 key=2 node=2',
                                             'transaction=2 operation=3 key=1 node=2',
                                             'transaction=2 operation=1 key=3 node=2',
                                             'transaction=1 operation=3 key=2 node=2',
                                             'transaction=1 operation=2 key=3 node=2',
                                             'transaction=3 operation=3 key=1 node=2'],
              'decentralized_lock': ['node=4'],
              'distributed_lock': ['node=2 epoch=1', 'node=3 epoch=1', 'node=2 epoch=2', 'node=4 epoch=1',
                                   'node=3 epoch=2', 'node=2 epoch=3', 'node=5 epoch=1', 'node=4 epoch=2',
                                   'node=3 epoch=3', 'node=2 epoch=4'],
              'leader': ['node=3 id=3'],
              'lock_server': ['client=1 server=1', 'client=2 server=1'],
              'multi_lock_server': ['node=4 lock=2'],
              'paxos': ['node=6 value=3 quorum=2 round=3'],
              'Ricart-Agrawala': ['node=2'],
              'shard': ['key=2 node=2 value=2'],
              'switch': ['node=2 packet=1', 'node=2 packet=2', 'node=3 packet=1']}

problemList = [
    "chord",
    "database_chain_replication",
    "distributed_lock",
    "leader",
    "switch",
    "lock_server",
    "Ricart-Agrawala",
    "consensus",
    "two_phase_commit"
]

result=[]
for problem in problemList:
    print '正在对' + problem + '进行I4 final测试'

    target_dict = final_dict

    suffix_str = ' "idn(N0) = ID0 & idn(N1) = ID1 & idn(N2) = ID2 & "' if problem == 'leader' else ''

    start_time = time.time()
    for instance_size in target_dict[problem]:
        command_str = base_str + problem + ' "' + instance_size + '"' + suffix_str
        print
        ''
        print
        'Now running: ' + command_str
        print
        ''
        os.system(command_str)
    end_time = time.time()
    time1='I4 final runtime: %.3f seconds' % (end_time - start_time)
    print time1
    print '正在对' + problem + '进行I4 total测试'
    target_dict = total_dict
    start_time1 = time.time()
    for instance_size in target_dict[problem]:
        command_str = base_str + problem + ' "' + instance_size + '"' + suffix_str
        print
        ''
        print
        'Now running: ' + command_str
        print
        ''
        os.system(command_str)
    end_time1 = time.time()
    time2 = 'I4 total runtime: %.3f seconds' % (end_time1 - start_time1)
    print time2
    result.append((problem,time1,time2))
print '测试完成，正在输出测试结果'
print 'protocol,final time,total time'
for res in result:
    print res[0]+','+ res[1]+','+ res[2]

