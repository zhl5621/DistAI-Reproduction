import subprocess


def run_mypyvy(protocol_value):
    # 构建命令列表
    command = [
        "python",
        "mypyvy/src/mypyvy.py",
        "fol-ic3",
        "--logic=universal",
        f"pyvs/{protocol_value}.pyv"
    ]

    # 使用subprocess运行命令
    result = subprocess.run(command, capture_output=True, text=True)

    # 输出命令的结果
    print(f"Command output: {result.stdout}")

    # 检查命令是否成功执行
    if result.returncode != 0:
        print(f"Command failed with error: {result.stderr}")

forAllList = [
    "multi_lock_server",
    "decentralized_lock",
    "distributed_lock",
    "shard",
    "leader",
    "lock_server",
    "blockchain",
    "Ricart-Agrawala",
    "two_phase_commit"
]
defaultList = [
    "lock_server",
    "Ricart-Agrawala",
    "two_phase_commit"
]
print("正在对协议进行FOL-IC3 forall 测试")
for PROTOCOL in forAllList:
    print("正在对"+PROTOCOL+"进行FOL-IC3 forall 测试")
    run_mypyvy(PROTOCOL)
print("正在对协议进行FOL-IC3 default 测试")
for PROTOCOL in defaultList:
    print("正在对"+PROTOCOL+"进行FOL-IC3 default 测试")
    run_mypyvy(PROTOCOL)




